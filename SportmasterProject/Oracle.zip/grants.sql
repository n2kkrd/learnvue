﻿grant execute on web_data_api to kubsu_study_web;
